@tool
class_name BTSettingsDialog
extends AcceptDialog

## [b]Project settings dialog[/b] for enabling tooltip modules and configuring documentation, appearance, preview and cache behavior.
## Changes are applied immediately; [kbd]Clear Tooltip Caches[/kbd] removes both RAM and persistent disk previews so the next hover regenerates them.
## The two-column layout keeps documentation, appearance and resource-preview settings visible without requiring a scrolling settings surface.

signal module_setting_changed(module_id: String, enabled: bool)
signal cache_clear_requested()
signal code_editor_integration_settings_changed()
signal documentation_help_requested(help_path: String, help_title: String)

const Settings := preload("res://addons/better_tooltips/tooltip_settings.gd")
const TOOLTIP_WRAP_COLUMNS := 64

const HELP_DOCUMENTATION_SYNTAX_PATH := "res://addons/better_tooltips/DOCUMENTATION_SYNTAX.txt"
const HELP_COMPONENT_DOCUMENTATION_PATH := "res://addons/better_tooltips/COMPONENT_DOCUMENTATION_HELP.txt"
const HELP_FILESYSTEM_GDSCRIPT_PATH := "res://addons/better_tooltips/FILESYSTEM_GDSCRIPT_HELP.txt"
const HELP_CODE_EDITOR_DOCUMENTATION_PATH := "res://addons/better_tooltips/CODE_EDITOR_DOCUMENTATION_HELP.txt"
const HELP_DOUBLE_HASH_PATH := "res://addons/better_tooltips/DOUBLE_HASH_DOCUMENTATION_HELP.txt"
const HELP_SINGLE_HASH_PATH := "res://addons/better_tooltips/SINGLE_HASH_DOCUMENTATION_HELP.txt"
const HELP_REPLACE_GODOT_DOCS_PATH := "res://addons/better_tooltips/REPLACE_GODOT_PROJECT_DOCS_HELP.txt"
const HELP_QUILL_PATH := "res://addons/better_tooltips/QUILL_IDE_INTEGRATION_HELP.txt"
const HELP_SCRIPT_IDE_PATH := "res://addons/better_tooltips/SCRIPT_IDE_INTEGRATION_HELP.txt"

@onready var _component_doc_help_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/ComponentDocumentationRow/btnComponentDocHelp
)
@onready var _gdscript_doc_help_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/GdscriptDocumentationRow/btnGdscriptDocHelp
)
@onready var _code_editor_doc_help_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorDocumentationRow/btnCodeEditorDocHelp
)
@onready var _documentation_comments_help_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/DocumentationCommentsRow/btnDocumentationCommentsHelp
)
@onready var _single_hash_help_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/SingleHashDocRow/btnSingleHashDocHelp
)
@onready var _replace_godot_member_docs_help_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/ReplaceGodotMemberDocsRow/btnReplaceGodotMemberDocsHelp
)
@onready var _quill_integration_help_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/QuillIntegrationRow/btnQuillIntegrationHelp
)
@onready var _script_ide_integration_help_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/ScriptIdeIntegrationRow/btnScriptIdeIntegrationHelp
)

@onready var _documentation_comments_checkbox: CheckBox = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/DocumentationCommentsRow/chkbDocumentationComments
)
@onready var _single_hash_checkbox: CheckBox = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/SingleHashDocRow/chkbSingleHashDoc
)
@onready var _replace_godot_member_docs_checkbox: CheckBox = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/ReplaceGodotMemberDocsRow/chkbReplaceGodotMemberDocs
)
@onready var _quill_integration_checkbox: CheckBox = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/QuillIntegrationRow/chkbQuillIntegration
)
@onready var _script_ide_integration_checkbox: CheckBox = (
	$MarginContainer/Columns/DocumentationColumn/CodeEditorOptionsIndent/CodeEditorOptions/ScriptIdeIntegrationRow/chkbScriptIdeIntegration
)
@onready var _background_contrast_spin: SpinBox = (
	$MarginContainer/Columns/DocumentationColumn/BackgroundContrastRow/spnBackgroundContrast
)
@onready var _safety_limit_spin: SpinBox = (
	$MarginContainer/Columns/DocumentationColumn/SafetyLimitRow/spnPreviewSafetyLimit
)
@onready var _clear_cache_button: Button = (
	$MarginContainer/Columns/DocumentationColumn/btnClearCaches
)
@onready var _plugin_diagnostics_checkbox: CheckBox = (
	$MarginContainer/Columns/PreviewColumn/chkbPluginDiagnostics
)
@onready var _preview_size_spin: SpinBox = (
	$MarginContainer/Columns/PreviewColumn/PreviewSizeRow/spnPreviewSize
)

@onready var _text_font_spin: SpinBox = $MarginContainer/Columns/DocumentationColumn/TextFontRow/spnTextFont
@onready var _text_width_spin: SpinBox = $MarginContainer/Columns/DocumentationColumn/TextWidthRow/spnTextWidth
@onready var _text_height_spin: SpinBox = $MarginContainer/Columns/DocumentationColumn/TextHeightRow/spnTextHeight

var _checkboxes: Dictionary = {}
var _documentation_help_buttons: Dictionary = {}

# Connects all settings controls once the dialog enters the editor tree and adds
# the shared actions that affect every module or the tooltip caches.
func _ready() -> void:
	_checkboxes = {
		Settings.MODULE_COMPONENT_DOCUMENTATION: $MarginContainer/Columns/DocumentationColumn/ComponentDocumentationRow/chkbComponentDoc,
		Settings.MODULE_SCRIPT_DOCUMENTATION: $MarginContainer/Columns/DocumentationColumn/GdscriptDocumentationRow/chkbGdscriptDoc,
		Settings.MODULE_CODE_EDITOR_DOCUMENTATION: $MarginContainer/Columns/DocumentationColumn/CodeEditorDocumentationRow/chkbCodeEditorDoc,
		Settings.MODULE_MARKDOWN_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbMarkdown,
		Settings.MODULE_TEXT_FILE_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbTextFiles,
		Settings.MODULE_MATERIAL_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbMaterials,
		Settings.MODULE_MESH_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbMeshes,
		Settings.MODULE_FONT_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbFonts,
		Settings.MODULE_SHADER_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbShaders,
		Settings.MODULE_SPRITE_FRAMES_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbSpriteFrames,
		Settings.MODULE_THEME_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbThemes,
		Settings.MODULE_STYLEBOX_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbStyleBoxes,
		Settings.MODULE_CURVE_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbCurves,
		Settings.MODULE_GRADIENT_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbGradients,
		Settings.MODULE_ENVIRONMENT_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbEnvironments,
		Settings.MODULE_SKY_PREVIEW: $MarginContainer/Columns/PreviewColumn/chkbSkies,
	}
	_documentation_help_buttons = {
		_component_doc_help_button: [HELP_COMPONENT_DOCUMENTATION_PATH, "Better Tooltips — Component Documentation"],
		_gdscript_doc_help_button: [HELP_FILESYSTEM_GDSCRIPT_PATH, "Better Tooltips — FileSystem GDScript Documentation"],
		_code_editor_doc_help_button: [HELP_CODE_EDITOR_DOCUMENTATION_PATH, "Better Tooltips — Code Editor Documentation"],
		_documentation_comments_help_button: [HELP_DOUBLE_HASH_PATH, "Better Tooltips — ## Documentation Comments"],
		_single_hash_help_button: [HELP_SINGLE_HASH_PATH, "Better Tooltips — Single # Comment Blocks"],
		_replace_godot_member_docs_help_button: [HELP_REPLACE_GODOT_DOCS_PATH, "Better Tooltips — Replace Duplicate Project Docs"],
		_quill_integration_help_button: [HELP_QUILL_PATH, "Better Tooltips — Quill IDE Integration"],
		_script_ide_integration_help_button: [HELP_SCRIPT_IDE_PATH, "Better Tooltips — Script-IDE Integration"],
	}
	for module_id in _checkboxes:
		var checkbox := _checkboxes[module_id] as CheckBox
		checkbox.toggled.connect(_on_checkbox_toggled.bind(module_id))
	_documentation_comments_checkbox.toggled.connect(
		_on_documentation_comments_toggled
	)
	_single_hash_checkbox.toggled.connect(_on_single_hash_toggled)
	_replace_godot_member_docs_checkbox.toggled.connect(
		_on_replace_godot_member_docs_toggled
	)
	_quill_integration_checkbox.toggled.connect(_on_quill_integration_toggled)
	_script_ide_integration_checkbox.toggled.connect(_on_script_ide_integration_toggled)
	_background_contrast_spin.value_changed.connect(
		_on_background_contrast_changed
	)
	_safety_limit_spin.value_changed.connect(
		_on_preview_safety_limit_changed
	)
	_preview_size_spin.value_changed.connect(_on_preview_size_changed)
	_text_font_spin.value_changed.connect(func(value: float) -> void: Settings.set_text_font_percent(roundi(value)))
	_text_width_spin.value_changed.connect(func(value: float) -> void: Settings.set_text_max_width(roundi(value)))
	_text_height_spin.value_changed.connect(func(value: float) -> void: Settings.set_text_max_height(roundi(value)))
	_clear_cache_button.pressed.connect(_on_clear_caches_pressed)
	_plugin_diagnostics_checkbox.toggled.connect(Settings.set_plugin_diagnostics_enabled)
	for button_variant in _documentation_help_buttons:
		var button := button_variant as Button
		var entry: Array = _documentation_help_buttons[button]
		button.pressed.connect(_emit_documentation_help.bind(str(entry[0]), str(entry[1])))
	ok_button_text = "Close"
	var enable_all_button := add_button("Enable All", false, "enable_all")
	var disable_all_button := add_button("Disable All", false, "disable_all")
	var reset_button := add_button("Reset to Defaults", false, "reset_defaults")
	reset_button.tooltip_text = _wrap_tooltip(
		"Restore all Better Tooltips settings for this project, including modules, appearance, and preview settings. Does not clear cached previews."
	)

	_configure_setting_tooltips(enable_all_button, disable_all_button)
	custom_action.connect(_on_custom_action)
	refresh()

func _emit_documentation_help(help_path: String, help_title: String) -> void:
	documentation_help_requested.emit(help_path, help_title)
	
# Refreshes controls from project metadata without emitting change signals, so
# simply opening the dialog never rewrites project-scoped editor settings.
func refresh() -> void:
	if _checkboxes.is_empty():
		return
	for module_id in _checkboxes:
		var checkbox := _checkboxes[module_id] as CheckBox
		checkbox.set_pressed_no_signal(Settings.is_module_enabled(module_id))
	_documentation_comments_checkbox.set_pressed_no_signal(
		Settings.is_documentation_comments_enabled()
	)
	_single_hash_checkbox.set_pressed_no_signal(
		Settings.is_single_hash_member_documentation_enabled()
	)
	_replace_godot_member_docs_checkbox.set_pressed_no_signal(
		Settings.is_replace_godot_member_documentation_enabled()
	)
	_quill_integration_checkbox.set_pressed_no_signal(
		Settings.is_quill_ide_integration_enabled()
	)
	_script_ide_integration_checkbox.set_pressed_no_signal(
		Settings.is_script_ide_integration_enabled()
	)
	_update_code_editor_option_availability()
	_background_contrast_spin.set_value_no_signal(
		Settings.get_tooltip_background_contrast_percent()
	)
	_safety_limit_spin.set_value_no_signal(Settings.get_preview_safety_limit_ms())
	_preview_size_spin.set_value_no_signal(Settings.get_preview_size_percent())
	_plugin_diagnostics_checkbox.set_pressed_no_signal(Settings.is_plugin_diagnostics_enabled())
	_text_font_spin.set_value_no_signal(Settings.get_text_font_percent())
	_text_width_spin.set_value_no_signal(Settings.get_text_max_width())
	_text_height_spin.set_value_no_signal(Settings.get_text_max_height())

# Persists one module checkbox and tells the controller to apply the change to
# the current editor integration immediately.
func _on_checkbox_toggled(enabled: bool, module_id: String) -> void:
	Settings.set_module_enabled(module_id, enabled)
	module_setting_changed.emit(module_id, enabled)
	if module_id == Settings.MODULE_CODE_EDITOR_DOCUMENTATION:
		_update_code_editor_option_availability()

# Stores whether normal Godot ## comments are shown through the shared Code
# Editor renderer. The active integration reads the value for every new tooltip.
func _on_documentation_comments_toggled(enabled: bool) -> void:
	Settings.set_documentation_comments_enabled(enabled)
	_update_code_editor_option_availability()

# Stores the optional add-on-only # documentation behavior. The active CodeEdit
# integration reads this setting when each tooltip is created, so no reload is needed.
func _on_single_hash_toggled(enabled: bool) -> void:
	Settings.set_single_hash_member_documentation_enabled(enabled)

# Controls whether duplicate native project-member descriptions are hidden in
# favor of the shared renderer. Godot engine API help is never affected.
func _on_replace_godot_member_docs_toggled(enabled: bool) -> void:
	Settings.set_replace_godot_member_documentation_enabled(enabled)

# Enables or disables only the optional Quill navigation bridge. Standard Godot
# CodeEdit and script-list documentation remain active when this is disabled.
func _on_quill_integration_toggled(enabled: bool) -> void:
	Settings.set_quill_ide_integration_enabled(enabled)
	code_editor_integration_settings_changed.emit()

# Enables or disables only the optional Script-IDE navigation bridge. Standard
# Godot and Quill integration settings remain independent.
func _on_script_ide_integration_toggled(enabled: bool) -> void:
	Settings.set_script_ide_integration_enabled(enabled)
	code_editor_integration_settings_changed.emit()

# Stores the visual separation between add-on-owned sections and Godot's native
# tooltip background. Newly created tooltips read the current value immediately.
func _on_background_contrast_changed(value: float) -> void:
	Settings.set_tooltip_background_contrast_percent(roundi(value))

func _update_code_editor_option_availability() -> void:
	var code_checkbox := (
		_checkboxes.get(Settings.MODULE_CODE_EDITOR_DOCUMENTATION, null) as CheckBox
	)
	var code_enabled := code_checkbox != null and code_checkbox.button_pressed
	_documentation_comments_checkbox.disabled = not code_enabled
	_single_hash_checkbox.disabled = not code_enabled
	_replace_godot_member_docs_checkbox.disabled = (
		not code_enabled or not _documentation_comments_checkbox.button_pressed
	)
	_quill_integration_checkbox.disabled = not code_enabled
	_script_ide_integration_checkbox.disabled = not code_enabled

# Persists the generous safety limit. Ordinary slow previews are not rejected;
# the limit only stops work at safe checkpoints while expensive work remains.
func _on_preview_safety_limit_changed(value: float) -> void:
	Settings.set_preview_safety_limit_ms(roundi(value))

# Persists the default size used when graphical previews are rendered into the
# shared cache. The size is part of the cache signature, so new hovers regenerate
# at the selected size without requiring an explicit cache clear.
func _on_preview_size_changed(value: float) -> void:
	Settings.set_preview_size_percent(roundi(value))

# Requests that the controller clears bounded RAM entries, transient failures and
# persistent disk previews. The next hover regenerates the current file version.
func _on_clear_caches_pressed() -> void:
	cache_clear_requested.emit()
	set_cache_available(false)

# Updates both the clear button's enabled state and its explanatory tooltip. The
# controller calls this when opening the dialog and after an explicit clear.
func set_cache_available(has_cache: bool) -> void:
	if not is_instance_valid(_clear_cache_button):
		return
	_clear_cache_button.disabled = not has_cache
	if has_cache:
		_clear_cache_button.tooltip_text = _wrap_tooltip(
			"Cached previews or remembered preview failures are present. Clears the add-on's RAM cache, failure cache and persistent preview files; affected resources are regenerated on the next hover."
		)
	else:
		_clear_cache_button.tooltip_text = _wrap_tooltip(
			"No tooltip preview cache is currently stored, so there is nothing to clear. The button becomes available after a preview result or failure has been cached."
		)

# Applies the same enabled state to every module while retaining the user's
# individual Code Editor documentation preferences as sub-options.
func _set_all(enabled: bool) -> void:
	for module_id in _checkboxes:
		var checkbox := _checkboxes[module_id] as CheckBox
		if checkbox.button_pressed == enabled:
			continue
		checkbox.set_pressed_no_signal(enabled)
		Settings.set_module_enabled(module_id, enabled)
		module_setting_changed.emit(module_id, enabled)
	_update_code_editor_option_availability()

# Confirm this destructive settings action; settings are applied immediately
# elsewhere in the dialog, so resetting must not be triggered by mistake.
func _confirm_reset_defaults() -> void:
	var confirmation := ConfirmationDialog.new()
	confirmation.title = "Reset Better Tooltips Settings"
	confirmation.dialog_text = "Reset all Better Tooltips settings for this project to their defaults?"
	confirmation.ok_button_text = "Reset"
	add_child(confirmation)
	confirmation.confirmed.connect(_reset_to_defaults)
	confirmation.close_requested.connect(confirmation.queue_free)
	confirmation.canceled.connect(confirmation.queue_free)
	confirmation.confirmed.connect(confirmation.queue_free, CONNECT_DEFERRED)
	confirmation.popup_centered()

func _reset_to_defaults() -> void:
	var prior_modules := {}
	for module_id in _checkboxes:
		prior_modules[module_id] = Settings.is_module_enabled(module_id)
	Settings.reset_to_defaults()
	refresh()
	for module_id in _checkboxes:
		var enabled := Settings.is_module_enabled(module_id)
		if bool(prior_modules[module_id]) != enabled:
			module_setting_changed.emit(module_id, enabled)
	code_editor_integration_settings_changed.emit()

# Adds explanatory hover text to every actual setting, including the less
# obvious cache/safety controls, so the dialog is understandable on its own.
func _configure_setting_tooltips(
	enable_all_button: Button,
	disable_all_button: Button
) -> void:
	var module_tooltips := {
		Settings.MODULE_COMPONENT_DOCUMENTATION: "Optional, off by default. Shows documentation for scenes/scripts that declare COMPONENT_CONTRACT v1. Includes exported properties, saved scene assignments and live assignments in the Scene dock. Click ? for setup instructions and an example.",
		Settings.MODULE_SCRIPT_DOCUMENTATION: "Adds class_name and Godot ## documentation to GDScript file tooltips and to nodes with an attached script in the Scene dock, including Implementation notes.",
		Settings.MODULE_CODE_EDITOR_DOCUMENTATION: "Extends Godot Code Editor symbol help and ScriptEditor navigation controls with project GDScript documentation. This includes the stock script list plus compatible tabs/outlines from Quill IDE and Script-IDE.",
		Settings.MODULE_MARKDOWN_PREVIEW: "Shows a live Markdown preview with editor-sized text. Long documents scroll inside the tooltip; graphical zoom is not used.",
		Settings.MODULE_TEXT_FILE_PREVIEW: "Shows a live editor-font preview for Godot TextFile entries other than Markdown. Long files scroll inside the tooltip.",
		Settings.MODULE_MATERIAL_PREVIEW: "Generates larger hover previews for supported 3D materials and spatial ShaderMaterials.",
		Settings.MODULE_MESH_PREVIEW: "Generates fitted 3D hover previews for Mesh resources.",
		Settings.MODULE_FONT_PREVIEW: "Shows rendered font samples in FileSystem tooltips.",
		Settings.MODULE_SHADER_PREVIEW: "Generates previews for supported spatial and canvas_item .gdshader resources.",
		Settings.MODULE_SPRITE_FRAMES_PREVIEW: "Shows a contact-sheet preview for SpriteFrames resources.",
		Settings.MODULE_THEME_PREVIEW: "Shows representative Godot controls rendered with the hovered Theme resource.",
		Settings.MODULE_STYLEBOX_PREVIEW: "Shows the hovered StyleBox on a representative panel.",
		Settings.MODULE_CURVE_PREVIEW: "Shows visual previews for Curve, Curve2D and Curve3D resources.",
		Settings.MODULE_GRADIENT_PREVIEW: "Shows the hovered Gradient over a transparency checkerboard.",
		Settings.MODULE_ENVIRONMENT_PREVIEW: "Renders Environment resources on a fixed reference scene.",
		Settings.MODULE_SKY_PREVIEW: "Renders Sky resources in a fixed wide-angle reference view.",
	}
	for module_id in _checkboxes:
		var checkbox := _checkboxes[module_id] as CheckBox
		checkbox.tooltip_text = _wrap_tooltip(
			str(module_tooltips.get(module_id, ""))
		)
	_component_doc_help_button.tooltip_text = _wrap_tooltip(
		"How to document a reusable scene with COMPONENT_CONTRACT. Opens a local help page with setup instructions, syntax and an example result."
	)
	_gdscript_doc_help_button.tooltip_text = _wrap_tooltip(
		"Explains FileSystem GDScript documentation and shows an example tooltip."
	)
	_code_editor_doc_help_button.tooltip_text = _wrap_tooltip(
		"Explains code-editor and navigation tooltips, including where project documentation appears."
	)
	_documentation_comments_help_button.tooltip_text = _wrap_tooltip(
		"Shows the supported ## documentation syntax and a rendered example."
	)
	_single_hash_help_button.tooltip_text = _wrap_tooltip(
		"Explains the optional single-# extension and shows how it appears in a tooltip."
	)
	_replace_godot_member_docs_help_button.tooltip_text = _wrap_tooltip(
		"Explains when duplicate native project docs are replaced and what remains native."
	)
	_quill_integration_help_button.tooltip_text = _wrap_tooltip(
		"Explains what the optional Quill IDE integration adds and when to disable it."
	)
	_script_ide_integration_help_button.tooltip_text = _wrap_tooltip(
		"Explains what the optional Script-IDE integration adds and when to disable it."
	)
	_documentation_comments_checkbox.tooltip_text = _wrap_tooltip(
		"Shows Godot-style ## documentation comments with the add-on renderer for supported project classes and members in code and ScriptEditor navigation tooltips. This preserves source line breaks and avoids the clipping behavior of Godot's compact native project documentation tooltip."
	)
	_single_hash_checkbox.tooltip_text = _wrap_tooltip(
		"Treats an ordinary contiguous # comment block directly above a supported project class/member as tooltip documentation in code and ScriptEditor navigation tooltips. This is an add-on extension for implementation-specific notes that should not become Godot API documentation."
	)
	_replace_godot_member_docs_checkbox.tooltip_text = _wrap_tooltip(
		"When Godot's native tooltip is showing the same project ## documentation, hide that duplicate description and render it with the add-on instead. Godot's own engine/API documentation and distinct inherited help remain untouched."
	)
	_quill_integration_checkbox.tooltip_text = _wrap_tooltip(
		"Searches for Quill IDE script tabs and outline controls and adds the same project documentation tooltips there. Disable this compatibility integration if a future Quill version changes its editor controls or causes problems; standard Godot code and script-list tooltips remain enabled."
	)
	_script_ide_integration_checkbox.tooltip_text = _wrap_tooltip(
		"Searches for Script-IDE script tabs and outline controls and adds the same project documentation tooltips there. Disable this compatibility integration if a future Script-IDE version changes its editor controls or causes problems; standard Godot code and script-list tooltips remain enabled."
	)
	_set_shared_tooltip(
		[
			$MarginContainer/Columns/DocumentationColumn/BackgroundContrastRow/lblBackgroundContrast,
			_background_contrast_spin,
		],
		"Changes only add-on-owned tooltip sections relative to Godot's current tooltip background. Dark themes are made lighter, light themes darker. 0% keeps the native background brightness."
	)
	_set_shared_tooltip(
		[
			$MarginContainer/Columns/DocumentationColumn/lblSafetyHint,
			$MarginContainer/Columns/DocumentationColumn/SafetyLimitRow/lblPreviewSafetyLimit,
			_safety_limit_spin,
		],
		"Maximum elapsed time for uncached resource-preview generation before the add-on stops at a safe checkpoint. 0 disables the limit. Hold Shift while hovering to force one regeneration attempt without the limit."
	)
	_set_shared_tooltip(
		[
			$MarginContainer/Columns/PreviewColumn/PreviewSizeRow/lblPreviewSize,
			_preview_size_spin,
		],
		"Default render size for cached graphical previews. While a graphical tooltip is visible, use the mouse wheel to resize only that hover temporarily; temporary zoom renders are never written to the cache. The live maximum is reduced automatically when necessary to keep the complete graphical tooltip within a manageable portion of the current screen."
	)
	_set_shared_tooltip(
		[$MarginContainer/Columns/DocumentationColumn/TextFontRow/lblTextFont, _text_font_spin],
		"Scales text and code tooltip fonts relative to the current Godot theme. 100% means one point smaller than the theme font. Graphical previews are unaffected."
	)
	_set_shared_tooltip(
		[$MarginContainer/Columns/DocumentationColumn/TextWidthRow/lblTextWidth, _text_width_spin],
		"Maximum width of text and code tooltip content in logical editor pixels. Also limited by the current screen. Graphical previews are unaffected."
	)
	_set_shared_tooltip(
		[$MarginContainer/Columns/DocumentationColumn/TextHeightRow/lblTextHeight, _text_height_spin],
		"Maximum height of text and code tooltips in logical editor pixels. Longer descriptions and source code scroll rather than being cut off. Graphical previews are unaffected."
	)
	enable_all_button.tooltip_text = _wrap_tooltip(
		"Enable every tooltip module for this project."
	)
	disable_all_button.tooltip_text = _wrap_tooltip(
		"Disable every tooltip module for this project."
	)

# Assigns one explanation to a label/control group that represents one setting,
# so hovering either the caption or the editor control shows the same help.
func _set_shared_tooltip(controls: Array, tooltip: String) -> void:
	for control_value in controls:
		var control := control_value as Control
		if control != null:
			control.tooltip_text = _wrap_tooltip(tooltip)

# Inserts explicit line breaks into native Godot tooltips so long descriptions
# stay readable instead of stretching across most of the editor window.
func _wrap_tooltip(text: String, max_columns: int = TOOLTIP_WRAP_COLUMNS) -> String:
	if text.is_empty() or max_columns <= 0:
		return text
	var result := PackedStringArray()
	for paragraph in text.split("\n", true):
		if paragraph.is_empty():
			result.append("")
			continue
		var line := ""
		for word in paragraph.split(" ", false):
			var candidate := str(word) if line.is_empty() else line + " " + str(word)
			if not line.is_empty() and candidate.length() > max_columns:
				result.append(line)
				line = str(word)
			else:
				line = candidate
		if not line.is_empty():
			result.append(line)
	return "\n".join(result)

# Handles the dialog's module-wide action buttons. Cache clearing has its own
# button in the cache section because the action belongs to those settings.
func _on_custom_action(action: StringName) -> void:
	match action:
		&"enable_all":
			_set_all(true)
		&"disable_all":
			_set_all(false)
		&"reset_defaults":
			_confirm_reset_defaults()
