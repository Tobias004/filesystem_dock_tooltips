@tool
class_name OutlineManager

const UNDERSCORE: StringName = &"_"
const INLINE: StringName = &"@"
const GETTER: StringName = &"get"
const SETTER: StringName = &"set"

const ENGINE_FUNCS: StringName = &"Engine Callbacks"
const FUNCS: StringName = &"Functions"
const SIGNALS: StringName = &"Signals"
const EXPORTED: StringName = &"Exported Properties"
const PROPERTIES: StringName = &"Properties"
const CLASSES: StringName = &"Classes"
const CONSTANTS: StringName = &"Constants"
const BOOKMARKS: StringName = &"Bookmarks"
const MAX_BOOKMARKS_HEIGHT: int = 150

var outline_container: Control
var outline_parent: Control
var split_container: HSplitContainer
var old_outline: ItemList
var outline_filter_txt: LineEdit
var sort_btn: Button
var outline_tree: Tree
var outline_root: TreeItem

var category_items: Dictionary[StringName, TreeItem] = {}

var collapse_button_container: HBoxContainer
var context_menu: PopupMenu

var bookmarks_container: VBoxContainer
var bookmarks_tree: Tree
var bookmarks_root: TreeItem
var bookmarks_context_menu: PopupMenu
var bookmarks_remove_all_btn: Button

var outline_cache: OutlineCache
var keywords: Dictionary[String, bool] = {}
var old_script_type: StringName

var settings_manager: QuillSettingsManager
var icon_manager: IconManager

func init(settings_mgr: QuillSettingsManager, icon_mgr: IconManager):
	settings_manager = settings_mgr
	icon_manager = icon_mgr

	EditorInterface.get_editor_settings().settings_changed.connect(_on_editor_settings_changed)

	var script_editor: ScriptEditor = EditorInterface.get_script_editor()
	split_container = find_or_null(script_editor.find_children("*", "HSplitContainer", true, false))
	outline_container = split_container.get_child(0)
	if settings_manager.is_outline_right:
		update_outline_position()

	old_outline = find_or_null(outline_container.find_children("*", "ItemList", true, false), 1)
	outline_parent = old_outline.get_parent()
	outline_parent.remove_child(old_outline)

	outline_tree = Tree.new()
	outline_tree.auto_translate_mode = Node.AUTO_TRANSLATE_MODE_DISABLED
	outline_tree.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outline_tree.hide_root = true
	outline_tree.allow_reselect = true
	outline_tree.scroll_horizontal_enabled = true
	outline_tree.scroll_vertical_enabled = true
	outline_parent.add_child(outline_tree)
	outline_tree.item_selected.connect(_on_outline_item_selected)
	outline_tree.item_collapsed.connect(_on_outline_item_collapsed)
	outline_tree.gui_input.connect(_on_outline_tree_gui_input)

	context_menu = PopupMenu.new()
	outline_tree.add_child(context_menu)
	context_menu.id_pressed.connect(_on_context_menu_id_pressed)
	context_menu.set_meta(&"target_item", null)

	outline_root = outline_tree.create_item()

	outline_filter_txt = find_or_null(outline_container.find_children("*", "LineEdit", true, false), 1)
	outline_filter_txt.gui_input.connect(_on_outline_filter_input)
	outline_filter_txt.text_changed.connect(_on_outline_filter_changed)

	sort_btn = find_or_null(outline_container.find_children("*", "Button", true, false))
	sort_btn.pressed.connect(update_outline)

	if not script_editor.editor_script_changed.is_connected(_on_active_script_changed):
		script_editor.editor_script_changed.connect(_on_active_script_changed)

	if not script_editor.script_changed.is_connected(_on_script_modified):
		script_editor.script_changed.connect(_on_script_modified)

	_add_collapse_buttons()
	_add_bookmarks_section()
	_add_scroll_buttons()

	_update_outline_ui_visibility()

func cleanup():
	if split_container != null:
		if outline_container and split_container != outline_container.get_parent():
			split_container.add_child(outline_container)

		if outline_container:
			split_container.move_child(outline_container, 0)

		if outline_filter_txt:
			if outline_filter_txt.gui_input.is_connected(_on_outline_filter_input):
				outline_filter_txt.gui_input.disconnect(_on_outline_filter_input)
			if outline_filter_txt.text_changed.is_connected(_on_outline_filter_changed):
				outline_filter_txt.text_changed.disconnect(_on_outline_filter_changed)
		if sort_btn:
			if sort_btn.pressed.is_connected(update_outline):
				sort_btn.pressed.disconnect(update_outline)
		if outline_tree:
			if outline_tree.item_selected.is_connected(_on_outline_item_selected):
				outline_tree.item_selected.disconnect(_on_outline_item_selected)
			if outline_tree.item_collapsed.is_connected(_on_outline_item_collapsed):
				outline_tree.item_collapsed.disconnect(_on_outline_item_collapsed)
			if outline_tree.gui_input.is_connected(_on_outline_tree_gui_input):
				outline_tree.gui_input.disconnect(_on_outline_tree_gui_input)
			if context_menu:
				context_menu.queue_free()
				context_menu = null

		if outline_parent and outline_tree:
			outline_parent.remove_child(outline_tree)
			outline_parent.add_child(old_outline)
			outline_parent.move_child(old_outline, 2)
			outline_tree.free()

		if bookmarks_container:
			bookmarks_container.queue_free()
			bookmarks_container = null
		if collapse_button_container:
			collapse_button_container.queue_free()
			collapse_button_container = null
		if scroll_button_container:
			scroll_button_container.queue_free()
			scroll_button_container = null

func update_editor():
	update_outline_cache()
	update_outline()
	_update_bookmarks_ui()

func _on_editor_settings_changed():
	if not settings_manager:
		return
	var old_position: bool = settings_manager.is_outline_right
	var old_hidden: bool = settings_manager.is_outline_hidden
	settings_manager.sync_settings_all()
	if settings_manager.is_outline_right != old_position:
		update_outline_position()
	if settings_manager.is_outline_hidden != old_hidden:
		_update_outline_ui_visibility()
	update_outline_cache()
	update_outline()
	_update_bookmarks_ui()


func _on_active_script_changed(script: Script):
	update_outline_cache()
	update_outline()

func _on_script_modified(script: Script):
	if script == EditorInterface.get_script_editor().get_current_script():
		update_outline_cache()
		update_outline()
		_cleanup_stale_bookmarks()

func update_outline_position():
	if not settings_manager or not split_container or not outline_container:
		return
	if settings_manager.is_outline_right:
		split_container.move_child(outline_container, 1)
	else:
		split_container.move_child(outline_container, 0)

func update_keywords(script: Script):
	if script == null:
		return

	var new_script_type: StringName = script.get_instance_base_type()
	if old_script_type != new_script_type:
		old_script_type = new_script_type
		keywords.clear()
		keywords["_static_init"] = true
		register_virtual_methods(new_script_type)

func register_virtual_methods(clazz: String):
	for method_dict in ClassDB.class_get_method_list(clazz):
		if method_dict[&"flags"] & METHOD_FLAG_VIRTUAL > 0:
			keywords[method_dict[&"name"]] = true

func update_outline_cache():
	outline_cache = null
	var script: Script = EditorInterface.get_script_editor().get_current_script()
	if not script:
		return

	update_keywords(script)

	if script.get_path().contains("::GDScript"):
		script = script.duplicate()

	outline_cache = OutlineCache.new()
	for_each_script_member(script, func(array: Array[String], item: String): array.append(item))

	var base_script: Script = script.get_base_script()
	if base_script != null:
		for_each_script_member(base_script, func(array: Array[String], item: String): array.erase(item))

func for_each_script_member(script: Script, consumer: Callable):
	var hide_private: bool = settings_manager.hide_private_members if settings_manager else false

	for dict in script.get_script_method_list():
		var func_name: String = dict[&"name"]
		if keywords.has(func_name):
			consumer.call(outline_cache.engine_funcs, func_name)
		else:
			if hide_private and func_name.begins_with(UNDERSCORE):
				continue
			if func_name.begins_with(INLINE):
				continue
			consumer.call(outline_cache.funcs, func_name)

	for dict in script.get_script_property_list():
		var property_name: String = dict[&"name"]
		if hide_private and property_name.begins_with(UNDERSCORE):
			continue

		var usage: int = dict[&"usage"]
		if usage & PROPERTY_USAGE_SCRIPT_VARIABLE:
			if usage & PROPERTY_USAGE_STORAGE and usage & PROPERTY_USAGE_EDITOR:
				consumer.call(outline_cache.exports, property_name)
			else:
				consumer.call(outline_cache.properties, property_name)

	for dict in script.get_property_list():
		var property_name: String = dict[&"name"]
		if hide_private and property_name.begins_with(UNDERSCORE):
			continue

		var usage: int = dict[&"usage"]
		if usage & PROPERTY_USAGE_SCRIPT_VARIABLE:
			consumer.call(outline_cache.properties, property_name)

	for dict in script.get_script_signal_list():
		var signal_name: String = dict[&"name"]
		consumer.call(outline_cache.signals, signal_name)

	for name_key in script.get_script_constant_map().keys():
		if hide_private and name_key.begins_with(UNDERSCORE):
			continue
		var obj: Variant = script.get_script_constant_map()[name_key]
		if obj is GDScript and not obj.has_source_code():
			consumer.call(outline_cache.classes, name_key)
		else:
			consumer.call(outline_cache.constants, name_key)

func update_outline():
	if not outline_tree or not outline_root:
		return
	if not icon_manager or not settings_manager:
		return

	outline_tree.clear()
	outline_root = outline_tree.create_item()
	category_items.clear()

	if outline_cache == null:
		return

	var filter_text: String = outline_filter_txt.get_text().to_lower() if outline_filter_txt else ""

	var categories_data = [
		{&"name": ENGINE_FUNCS, &"items": outline_cache.engine_funcs, &"icon": icon_manager.engine_func_icon, &"type": &"func", &"enabled": settings_manager.show_engine_funcs},
		{&"name": FUNCS, &"items": outline_cache.funcs, &"icon": icon_manager.func_icon, &"type": &"func", &"use_func_icons": true, &"enabled": settings_manager.show_funcs},
		{&"name": SIGNALS, &"items": outline_cache.signals, &"icon": icon_manager.signal_icon, &"type": &"signal", &"enabled": settings_manager.show_signals},
		{&"name": EXPORTED, &"items": outline_cache.exports, &"icon": icon_manager.export_icon, &"type": &"var", &"modifier": &"@export", &"enabled": settings_manager.show_exported},
		{&"name": PROPERTIES, &"items": outline_cache.properties, &"icon": icon_manager.property_icon, &"type": &"var", &"enabled": settings_manager.show_properties},
		{&"name": CLASSES, &"items": outline_cache.classes, &"icon": icon_manager.class_icon, &"type": &"class", &"enabled": settings_manager.show_classes},
		{&"name": CONSTANTS, &"items": outline_cache.constants, &"icon": icon_manager.constant_icon, &"type": &"const", &"modifier": &"enum", &"enabled": settings_manager.show_constants}
	]

	categories_data.sort_custom(func(a, b): return get_category_order(a[&"name"]) < get_category_order(b[&"name"]))

	for category_data in categories_data:
		var items: Array[String] = category_data[&"items"]
		if items.is_empty() or not category_data[&"enabled"]:
			continue

		var filtered_items: Array[String] = []
		for item in items:
			if filter_text.is_empty() or item.to_lower().contains(filter_text):
				filtered_items.append(item)

		if filtered_items.is_empty():
			continue

		if settings_manager.is_sorted():
			filtered_items.sort_custom(func(str1: String, str2: String): return str1.naturalnocasecmp_to(str2) < 0)

		var category_item: TreeItem = outline_tree.create_item(outline_root)
		category_item.set_text(0, category_data[&"name"] + " (" + str(filtered_items.size()) + ")")
		category_item.set_icon(0, category_data[&"icon"])
		category_item.set_selectable(0, false)
		category_item.collapsed = get_category_collapsed_state(category_data[&"name"])
		category_items[category_data[&"name"]] = category_item

		for item in filtered_items:
			var item_node: TreeItem = outline_tree.create_item(category_item)
			item_node.set_text(0, item)

			var item_icon: Texture2D = category_data[&"icon"]
			if category_data.has(&"use_func_icons"):
				item_icon = icon_manager.get_func_icon(item)
			item_node.set_icon(0, item_icon)

			var metadata: Dictionary[StringName, StringName] = {
				&"type": category_data[&"type"],
				&"modifier": category_data.get(&"modifier", &"")
			}
			item_node.set_metadata(0, metadata)


func get_category_order(category_name: StringName) -> int:
	var index = settings_manager.outline_order.find(category_name)
	return index if index != -1 else 999

func get_category_collapsed_state(category_name: StringName) -> bool:
	return settings_manager.collapsed_categories.has(category_name)

func find_and_goto_line(name: String, type: StringName, modifier: StringName, script: Script) -> void:
	if not script:
		return

	var with_text: String = type + " " + name
	if type == &"func":
		with_text += "("

	var lines: PackedStringArray = script.get_source_code().split("\n")
	var index: int = 0
	for line in lines:
		if line.begins_with(with_text):
			goto_line(index)
			return
		if modifier != &"" and line.begins_with(modifier):
			if line.begins_with(modifier + " " + with_text):
				goto_line(index)
				return
			elif modifier == &"enum" and line.contains("enum " + name):
				goto_line(index)
				return
		if type == &"var" and line.contains(with_text):
			goto_line(index)
			return
		index += 1

	push_error(with_text + " or " + modifier + " not found in source code")

func scroll_to_outline_item():
	var selected_item: TreeItem = outline_tree.get_selected()
	if not selected_item:
		return
	if not selected_item.get_metadata(0):
		return

	var script: Script = EditorInterface.get_script_editor().get_current_script()
	if not script:
		return

	var text: String = selected_item.get_text(0)
	var metadata: Dictionary = selected_item.get_metadata(0)
	var modifier: StringName = metadata[&"modifier"]
	var type: StringName = metadata[&"type"]

	find_and_goto_line(text, type, modifier, script)

func goto_line(index: int):
	var script_editor: ScriptEditor = EditorInterface.get_script_editor()
	script_editor.goto_line(index)

	var code_edit: CodeEdit = script_editor.get_current_editor().get_base_editor()
	code_edit.set_caret_line(index)
	code_edit.set_v_scroll(index)
	code_edit.set_caret_column(code_edit.get_line(index).length())
	code_edit.set_h_scroll(0)
	code_edit.grab_focus()

func _on_outline_item_selected():
	var item: TreeItem = outline_tree.get_selected()
	if not item or not item.get_metadata(0):
		return
	scroll_to_outline_item()

func _on_outline_item_collapsed(item: TreeItem):
	for category_name in category_items.keys():
		if category_items[category_name] == item:
			settings_manager.set_category_collapsed(category_name, item.collapsed)
			break

func _on_outline_tree_gui_input(event: InputEvent):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		var item: TreeItem = outline_tree.get_item_at_position(event.position)
		if item and item.get_metadata(0):
			item.select(0)
			_show_context_menu(item, event.position)

func _show_context_menu(item: TreeItem, at_position: Vector2):
	context_menu.clear()

	var metadata: Dictionary = item.get_metadata(0)
	var name: String = item.get_text(0)
	var script: Script = EditorInterface.get_script_editor().get_current_script()
	var item_icon: Texture2D = item.get_icon(0)

	context_menu.set_meta(&"target_item", item)

	var script_path: String = script.resource_path if script else &""
	var already_bookmarked: bool = false
	if not script_path.is_empty():
		already_bookmarked = settings_manager.is_bookmarked(script_path, name)

	if already_bookmarked:
		context_menu.add_icon_item(item_icon, "Remove Bookmark", 0)
	else:
		context_menu.add_icon_item(item_icon, "Add Bookmark", 0)

	context_menu.position = Vector2i(outline_tree.get_screen_position()) + Vector2i(at_position)
	context_menu.popup()

func _on_context_menu_id_pressed(id: int):
	var item: TreeItem = context_menu.get_meta(&"target_item")
	if not item:
		return

	var metadata: Dictionary = item.get_metadata(0)
	var name: String = item.get_text(0)

	if id == 0:
		var script: Script = EditorInterface.get_script_editor().get_current_script()
		if script:
			var script_path: String = script.resource_path
			if settings_manager.is_bookmarked(script_path, name):
				settings_manager.remove_bookmark(script_path, name)
			else:
				settings_manager.add_bookmark(
					script_path,
					name,
					metadata[&"type"],
					metadata.get(&"modifier", &"")
				)
		update_outline()
		_update_bookmarks_ui()

func _on_bookmarks_tree_item_selected():
	var item: TreeItem = bookmarks_tree.get_selected()
	if not item or not item.get_metadata(0):
		return
	var metadata: Dictionary = item.get_metadata(0)
	_navigate_to_bookmark(metadata)

func _on_bookmarks_tree_gui_input(event: InputEvent):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		var item: TreeItem = bookmarks_tree.get_item_at_position(event.position)
		if item and item.get_metadata(0):
			item.select(0)
			_show_bookmarks_context_menu(item, event.position)

func _show_bookmarks_context_menu(item: TreeItem, at_position: Vector2):
	bookmarks_context_menu.clear()

	var metadata: Dictionary = item.get_metadata(0)
	var item_icon: Texture2D = item.get_icon(0)
	bookmarks_context_menu.set_meta(&"target_item", item)
	bookmarks_context_menu.add_icon_item(item_icon, "Remove Bookmark", 0)

	bookmarks_context_menu.position = Vector2i(bookmarks_tree.get_screen_position()) + Vector2i(at_position)
	bookmarks_context_menu.popup()

func _on_bookmarks_context_menu_id_pressed(id: int):
	var item: TreeItem = bookmarks_context_menu.get_meta(&"target_item")
	if not item:
		return

	var metadata: Dictionary = item.get_metadata(0)

	if id == 0:
		settings_manager.remove_bookmark(
			metadata[&"script_path"],
			metadata[&"bookmark_name"]
		)
	_update_bookmarks_ui()

func _navigate_to_bookmark(metadata: Dictionary) -> void:
	var script_path: String = metadata.get(&"script_path", &"")
	if script_path.is_empty():
		return
	var script: Script = load(script_path)
	if not script:
		return
	EditorInterface.edit_resource(script)
	call_deferred("_navigate_to_bookmark_deferred", metadata)

func _navigate_to_bookmark_deferred(metadata: Dictionary) -> void:
	var script_path: String = metadata.get(&"script_path", &"")
	if script_path.is_empty():
		return
	var script: Script = load(script_path)
	find_and_goto_line(
		metadata.get(&"bookmark_name", &""),
		metadata.get(&"type", &""),
		metadata.get(&"modifier", &""),
		script
	)

func _add_bookmarks_section():
	bookmarks_container = VBoxContainer.new()
	bookmarks_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bookmarks_container.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	bookmarks_container.custom_minimum_size.y = 24

	var header: HBoxContainer = HBoxContainer.new()
	header.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.custom_minimum_size.y = 24

	var editor_settings: EditorSettings = EditorInterface.get_editor_settings()
	var base_color: Color = editor_settings.get_setting("interface/theme/base_color")

	var header_normal: StyleBoxFlat = StyleBoxFlat.new()
	header_normal.bg_color = base_color.darkened(0.2)
	header_normal.corner_radius_top_left = 8
	header_normal.corner_radius_top_right = 8
	header_normal.corner_radius_bottom_right = 8
	header_normal.corner_radius_bottom_left = 8
	header_normal.expand_margin_top = -2
	header_normal.expand_margin_bottom = -2
	header_normal.expand_margin_left = -2
	header_normal.expand_margin_right = -2

	var header_hover: StyleBoxFlat = header_normal.duplicate()
	header_hover.bg_color = base_color.lightened(0.1)

	var header_focus: StyleBoxFlat = header_normal.duplicate()
	header_focus.bg_color = base_color.darkened(0.3)

	var bookmarks_label: Label = Label.new()
	bookmarks_label.text = BOOKMARKS + " (0)"
	bookmarks_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bookmarks_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bookmarks_label.add_theme_font_size_override("font_size", 12)
	header.add_child(bookmarks_label)

	var remove_all_btn: Button = Button.new()
	remove_all_btn.text = "Remove All"
	remove_all_btn.tooltip_text = "Remove all bookmarks"
	remove_all_btn.size_flags_horizontal = Control.SIZE_SHRINK_END
	bookmarks_remove_all_btn = remove_all_btn
	remove_all_btn.pressed.connect(_remove_all_bookmarks)
	remove_all_btn.custom_minimum_size.x = 80
	remove_all_btn.add_theme_stylebox_override("hover", header_hover)
	remove_all_btn.add_theme_stylebox_override("normal", header_normal)
	remove_all_btn.add_theme_stylebox_override("pressed", header_focus)
	header.add_child(remove_all_btn)

	bookmarks_container.add_child(header)

	var bookmarks_scroll: ScrollContainer = ScrollContainer.new()
	bookmarks_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bookmarks_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	bookmarks_scroll.custom_minimum_size.y = 0
	bookmarks_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	bookmarks_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	bookmarks_container.add_child(bookmarks_scroll)

	bookmarks_tree = Tree.new()
	bookmarks_tree.auto_translate_mode = Node.AUTO_TRANSLATE_MODE_DISABLED
	bookmarks_tree.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bookmarks_tree.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	bookmarks_tree.custom_minimum_size.y = 0
	bookmarks_tree.hide_root = true
	bookmarks_tree.allow_reselect = true
	bookmarks_tree.scroll_horizontal_enabled = false
	bookmarks_tree.scroll_vertical_enabled = false
	bookmarks_root = bookmarks_tree.create_item()
	bookmarks_tree.item_selected.connect(_on_bookmarks_tree_item_selected)
	bookmarks_tree.gui_input.connect(_on_bookmarks_tree_gui_input)
	bookmarks_scroll.add_child(bookmarks_tree)

	bookmarks_context_menu = PopupMenu.new()
	bookmarks_tree.add_child(bookmarks_context_menu)
	bookmarks_context_menu.id_pressed.connect(_on_bookmarks_context_menu_id_pressed)
	bookmarks_context_menu.set_meta(&"target_item", null)

	outline_parent.add_child(bookmarks_container)
	var scroll_idx: int = outline_parent.get_child_count() - 1
	outline_parent.move_child(bookmarks_container, scroll_idx)

	_update_bookmarks_ui()

func _update_bookmarks_ui():
	if not bookmarks_tree or not bookmarks_root:
		return

	bookmarks_tree.clear()
	bookmarks_root = bookmarks_tree.create_item()

	var bookmarks_data: Array = settings_manager.bookmarks
	var count: int = bookmarks_data.size()

	var header: HBoxContainer = bookmarks_container.get_child(0) if bookmarks_container.get_child_count() > 0 else null
	if header:
		var label: Label = header.get_child(0)
		if label:
			label.text = BOOKMARKS + " (" + str(count) + ")"

	if count == 0:
		bookmarks_tree.visible = false
		bookmarks_container.custom_minimum_size.y = 24
		bookmarks_remove_all_btn.visible = false
		return

	bookmarks_tree.visible = true
	bookmarks_remove_all_btn.visible = true
	bookmarks_container.custom_minimum_size.y = MAX_BOOKMARKS_HEIGHT

	for bookmark in bookmarks_data:
		var script_filename: String = bookmark[&"script_path"].get_file()
		var display_text: String = script_filename + " > " + bookmark[&"name"]

		var bm_item: TreeItem = bookmarks_tree.create_item(bookmarks_root)
		bm_item.set_text(0, display_text)

		var item_type: StringName = bookmark.get(&"type", &"func")
		var item_name: String = bookmark[&"name"]
		var modifier: StringName = bookmark.get(&"modifier", &"")
		if item_type == &"func" and item_name.begins_with("get"):
			bm_item.set_icon(0, icon_manager.func_get_icon)
		elif item_type == &"func" and item_name.begins_with("set"):
			bm_item.set_icon(0, icon_manager.func_set_icon)
		elif item_type == &"func" and keywords.has(item_name):
			bm_item.set_icon(0, icon_manager.engine_func_icon)
		else:
			match item_type:
				&"signal": bm_item.set_icon(0, icon_manager.signal_icon)
				&"var":
					if modifier == &"@export":
						bm_item.set_icon(0, icon_manager.export_icon)
					else:
						bm_item.set_icon(0, icon_manager.property_icon)
				&"const": bm_item.set_icon(0, icon_manager.constant_icon)
				&"class": bm_item.set_icon(0, icon_manager.class_icon)
				_: bm_item.set_icon(0, icon_manager.func_icon)

		bm_item.set_metadata(0, {
			&"is_bookmark": true,
			&"script_path": bookmark[&"script_path"],
			&"bookmark_name": bookmark[&"name"],
			&"type": item_type,
			&"modifier": bookmark.get(&"modifier", &"")
		})

func _remove_all_bookmarks():
	settings_manager.clear_all_bookmarks()
	_update_bookmarks_ui()

func _cleanup_stale_bookmarks() -> void:
	var script: Script = EditorInterface.get_script_editor().get_current_script()
	if not script or not outline_cache:
		return

	var script_path: String = script.resource_path
	if script_path.is_empty():
		return

	var existing: Dictionary = {}
	for name: String in outline_cache.engine_funcs:
		existing[name] = true
	for name: String in outline_cache.funcs:
		existing[name] = true
	for name: String in outline_cache.signals:
		existing[name] = true
	for name: String in outline_cache.exports:
		existing[name] = true
	for name: String in outline_cache.properties:
		existing[name] = true
	for name: String in outline_cache.constants:
		existing[name] = true
	for name: String in outline_cache.classes:
		existing[name] = true

	var changed: bool = false
	var i: int = 0
	while i < settings_manager.bookmarks.size():
		var bm: Dictionary = settings_manager.bookmarks[i]
		if bm["script_path"] == script_path and not existing.has(bm["name"]):
			settings_manager.bookmarks.remove_at(i)
			changed = true
		else:
			i += 1

	if changed:
		settings_manager._persist_bookmarks()
		_update_bookmarks_ui()

func _collapse_all():
	settings_manager.set_all_categories_collapsed(true)
	for category_item in category_items.values():
		category_item.collapsed = true

func _expand_all():
	settings_manager.set_all_categories_collapsed(false)
	for category_item in category_items.values():
		category_item.collapsed = false

func _on_outline_filter_input(event: InputEvent):
	navigate_on_tree(event, outline_tree)

func _on_outline_filter_changed(text: String):
	update_outline()

func navigate_on_tree(event: InputEvent, tree: Tree):
	if event.is_action_pressed(&"ui_text_submit"):
		scroll_to_outline_item()
		tree.accept_event()
	elif event.is_action_pressed(&"ui_down", true):
		var selected: TreeItem = tree.get_selected()
		if selected:
			var next: TreeItem = selected.get_next_in_tree()
			if next:
				next.select(0)
				tree.ensure_cursor_is_visible()
		elif tree.get_root() and tree.get_root().get_first_child():
			tree.get_root().get_first_child().select(0)
		tree.accept_event()
	elif event.is_action_pressed(&"ui_up", true):
		var selected: TreeItem = tree.get_selected()
		if selected:
			var prev: TreeItem = selected.get_prev_in_tree()
			if prev:
				prev.select(0)
				tree.ensure_cursor_is_visible()
		tree.accept_event()
	elif event.is_action_pressed(&"ui_right", true):
		var selected: TreeItem = tree.get_selected()
		if selected and selected.get_children():
			selected.collapsed = false
		tree.accept_event()
	elif event.is_action_pressed(&"ui_left", true):
		var selected: TreeItem = tree.get_selected()
		if selected:
			if selected.get_children() and not selected.collapsed:
				selected.collapsed = true
			else:
				var parent: TreeItem = selected.get_parent()
				if parent and parent != tree.get_root():
					parent.select(0)
		tree.accept_event()
	elif event is InputEventKey and tree.get_root() and tree.get_root().get_first_child():
		if not tree.get_selected():
			tree.get_root().get_first_child().select(0)

var scroll_button_container: HBoxContainer

func _update_outline_ui_visibility():
	if not settings_manager or not outline_tree:
		return
	var hidden: bool = settings_manager.is_outline_hidden

	outline_tree.visible = not hidden
	if collapse_button_container:
		collapse_button_container.visible = not hidden
	if bookmarks_container:
		bookmarks_container.visible = not hidden
	if scroll_button_container:
		scroll_button_container.visible = not hidden
	if outline_filter_txt:
		outline_filter_txt.visible = not hidden
	if sort_btn:
		sort_btn.visible = not hidden

func _add_collapse_buttons():
	if collapse_button_container:
		collapse_button_container.free()

	collapse_button_container = HBoxContainer.new()
	collapse_button_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	collapse_button_container.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	collapse_button_container.custom_minimum_size.y = 28

	var editor_settings: EditorSettings = EditorInterface.get_editor_settings()
	var base_color: Color = editor_settings.get_setting("interface/theme/base_color")

	var normal: StyleBoxFlat = StyleBoxFlat.new()
	normal.bg_color = base_color.darkened(0.2)
	normal.corner_radius_top_left = 8
	normal.corner_radius_top_right = 8
	normal.corner_radius_bottom_right = 8
	normal.corner_radius_bottom_left = 8
	normal.expand_margin_top = -2
	normal.expand_margin_bottom = -2
	normal.expand_margin_left = -2
	normal.expand_margin_right = -2

	var hover: StyleBoxFlat = normal.duplicate()
	hover.bg_color = base_color.lightened(0.1)

	var focus: StyleBoxFlat = normal.duplicate()
	focus.bg_color = base_color.darkened(0.3)

	var collapse_all_btn: Button = Button.new()
	collapse_all_btn.text = "Collapse"
	collapse_all_btn.tooltip_text = "Collapse all outline categories"
	collapse_all_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	collapse_all_btn.pressed.connect(_collapse_all)
	collapse_all_btn.custom_minimum_size.x = 80
	collapse_all_btn.add_theme_stylebox_override("hover", hover)
	collapse_all_btn.add_theme_stylebox_override("normal", normal)
	collapse_all_btn.add_theme_stylebox_override("pressed", focus)
	collapse_button_container.add_child(collapse_all_btn)

	var expand_all_btn: Button = Button.new()
	expand_all_btn.text = "Expand"
	expand_all_btn.tooltip_text = "Expand all outline categories"
	expand_all_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	expand_all_btn.pressed.connect(_expand_all)
	expand_all_btn.custom_minimum_size.x = 80
	expand_all_btn.add_theme_stylebox_override("hover", hover)
	expand_all_btn.add_theme_stylebox_override("normal", normal)
	expand_all_btn.add_theme_stylebox_override("pressed", focus)
	collapse_button_container.add_child(expand_all_btn)

	outline_parent.add_child(collapse_button_container)
	outline_parent.move_child(collapse_button_container, 0)

func _add_scroll_buttons():
	if scroll_button_container:
		scroll_button_container.free()

	scroll_button_container = HBoxContainer.new()
	scroll_button_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll_button_container.size_flags_vertical = Control.SIZE_FILL
	scroll_button_container.custom_minimum_size.y = 60

	var editor_settings: EditorSettings = EditorInterface.get_editor_settings()
	var base_color: Color = editor_settings.get_setting("interface/theme/base_color")

	var normal: StyleBoxFlat = StyleBoxFlat.new()
	normal.bg_color = base_color.darkened(0.2)
	normal.corner_radius_top_left = 12
	normal.corner_radius_top_right = 12
	normal.corner_radius_bottom_right = 12
	normal.corner_radius_bottom_left = 12
	normal.expand_margin_bottom = -3
	normal.expand_margin_top = -3
	normal.expand_margin_left = -3
	normal.expand_margin_right = -3

	var hover: StyleBoxFlat = normal.duplicate()
	hover.bg_color = base_color.lightened(0.1)

	var focus: StyleBoxFlat = normal.duplicate()
	focus.bg_color = base_color.darkened(0.3)

	var scroll_top_btn: Button = Button.new()
	scroll_top_btn.icon = icon_manager.scroll_top
	scroll_top_btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	scroll_top_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll_top_btn.pressed.connect(_scroll_to_top)
	scroll_top_btn.custom_minimum_size.x = 60
	scroll_top_btn.add_theme_stylebox_override("hover", hover)
	scroll_top_btn.add_theme_stylebox_override("normal", normal)
	scroll_top_btn.add_theme_stylebox_override("pressed", focus)
	scroll_top_btn.tooltip_text = "Scroll to Top"
	scroll_button_container.add_child(scroll_top_btn)

	var scroll_bottom_btn: Button = Button.new()
	scroll_bottom_btn.icon = icon_manager.scroll_bottom
	scroll_bottom_btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	scroll_bottom_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll_bottom_btn.pressed.connect(_scroll_to_bottom)
	scroll_bottom_btn.custom_minimum_size.x = 60
	scroll_bottom_btn.add_theme_stylebox_override("hover", hover)
	scroll_bottom_btn.add_theme_stylebox_override("normal", normal)
	scroll_bottom_btn.add_theme_stylebox_override("pressed", focus)
	scroll_bottom_btn.tooltip_text = "Scroll to Bottom"
	scroll_button_container.add_child(scroll_bottom_btn)

	outline_parent.add_child(scroll_button_container)
	outline_parent.move_child(scroll_button_container, outline_parent.get_child_count())

func _scroll_to_top():
	var script: Script = EditorInterface.get_script_editor().get_current_script()
	if not script:
		return

	var editor_base: ScriptEditorBase = EditorInterface.get_script_editor().get_current_editor()
	if not editor_base:
		return
	var code_edit: CodeEdit = editor_base.get_base_editor()
	if not code_edit:
		return
	code_edit.set_caret_line(0)
	code_edit.set_v_scroll(0)
	code_edit.set_caret_column(0)
	code_edit.set_h_scroll(0)
	code_edit.grab_focus()

func _scroll_to_bottom():
	var script: Script = EditorInterface.get_script_editor().get_current_script()
	if not script:
		return

	var lines: PackedStringArray = script.get_source_code().split("\n")
	var last_index: int = lines.size() - 1

	var editor_base: ScriptEditorBase = EditorInterface.get_script_editor().get_current_editor()
	if not editor_base:
		return
	var code_edit: CodeEdit = editor_base.get_base_editor()
	if not code_edit:
		return
	code_edit.set_caret_line(last_index)
	code_edit.set_v_scroll(last_index)
	code_edit.set_caret_column(lines[last_index].length())
	code_edit.set_h_scroll(0)
	code_edit.grab_focus()


func find_or_null(arr: Array[Node], index: int = 0) -> Node:
	if arr.is_empty():
		push_error("Required node not found for Script-IDE Outline Manager")
		return null
	return arr[index]

class OutlineCache:
	var classes: Array[String] = []
	var constants: Array[String] = []
	var signals: Array[String] = []
	var exports: Array[String] = []
	var properties: Array[String] = []
	var funcs: Array[String] = []
	var engine_funcs: Array[String] = []
